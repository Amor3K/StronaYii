<?php

namespace app\models;

use yii\db\ActiveRecord;

class Produkt extends ActiveRecord
{
    /**
     * Nazwa tabeli w bazie danych
     */
    public static function tableName()
    {
        return 'produkt';
    }

    /**
     * Zasady walidacji (opcjonalne, ale dobre praktyki)
     */
    public function rules()
    {
        return [
            [['nazwa', 'cena'], 'required'],
            ['nazwa', 'string', 'max' => 255],
            ['cena', 'number'],
        ];
    }
}
