<?php
$this->title = 'Lista Produktów';
$this->registerCss("
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    table {
        width: 80%;
        margin: 40px auto;
        border-collapse: collapse;
        box-shadow: 0 0 20px rgba(0,0,0,0.5);
        background-color: #1e1e1e;
        color: #fff;
    }
    th, td {
        padding: 15px;
        border: 1px solid #333;
        text-align: center;
    }
    th {
        background-color: #292929;
        font-weight: bold;
    }
    tr:nth-child(even) {
        background-color: #2c2c2c;
    }
    tr:hover {
        background-color: #3a3a3a;
    }
    h1 {
        text-align: center;
        color: #f1f1f1;
        margin-top: 30px;
    }
    .logo {
        display: block;
        margin: 20px auto;
        width: 150px;
        height: 150px;
        border-radius: 50%;
        border: 4px solid #999;
        object-fit: cover;
        background-color: #fff;
    }
    a {
        color: #4FC3F7;
        text-decoration: none;
    }
    a:hover {
        text-decoration: underline;
    }
");
?>

<h1><?= $this->title ?></h1>

<img src="<?= Yii::$app->request->baseUrl ?>/logo.png" alt="Logo sklepu" class="logo">

<table>
    <tr>
        <th>ID</th>
        <th>Nazwa</th>
        <th>Cena</th>
        <th>Link</th>
    </tr>
    <?php foreach ($produkty as $produkt): ?>
        <tr>
            <td><?= $produkt->id ?></td>
            <td><?= htmlspecialchars($produkt->nazwa) ?></td>
            <td><?= number_format($produkt->cena, 2, ',', ' ') ?> zł</td>
            <td>
                <?php if (!empty($produkt->link)): ?>
                    <a href="<?= htmlspecialchars($produkt->link) ?>" target="_blank">Zobacz</a>
                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
