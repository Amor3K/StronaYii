<?php

/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Obrazek przedstawiający bazę danych:</p>

    <img src="<?= Yii::$app->request->baseUrl ?>/baza danych.jpg" alt="Baza danych" style="max-width: 100%; border: 1px solid #ccc;">
</div>
